# Changelog


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Translations starter template included


Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
